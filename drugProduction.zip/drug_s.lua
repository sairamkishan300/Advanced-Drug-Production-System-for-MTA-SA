-- ====================================
-- Inventory Management Functions
-- ====================================

if not Config then
    outputDebugString("[Drug System] Error: Config not loaded", 1)
    return
end
-- ====================================
-- Main Script
-- ====================================

local pots = {}

-- Drug dealing variables
local activeOrders = {}
local playerOrders = {}

-- Action cooldowns
local playerCooldowns = {}

-- ====================================
-- Exported Functions
-- ====================================

function placePot(player)
    if not isElement(player) then return false end
    
    if not hasInventoryItem(player, Config.REQUIRED_ITEMS.POT) then
        outputChatBox("You need a pot to do this!", player, 255, 0, 0)
        return false
    end
    
    local x, y, z = getElementPosition(player)
    
    -- Create pot object slightly in front of player
    local pot = createObject(Config.OBJECT_MODELS.EMPTY_POT, x, y, z - 0.5)
    if not pot then 
        outputChatBox("Failed to create pot!", player, 255, 0, 0)
        return false
    end
    
    -- Create interaction marker
    local marker = createMarker(x, y, z - 0.5, "cylinder", Config.MARKER_SIZE, 
        Config.MARKER_COLOR.r, 
        Config.MARKER_COLOR.g, 
        Config.MARKER_COLOR.b, 
        Config.MARKER_COLOR.a)
    
    if not marker then
        destroyElement(pot)
        outputChatBox("Failed to create marker!", player, 255, 0, 0)
        return false
    end
    
    -- Remove pot item from inventory
    if not takeInventoryItem(player, Config.REQUIRED_ITEMS.POT) then
        destroyElement(pot)
        destroyElement(marker)
        return false
    end
    
    -- Store pot data
    local potID = #pots + 1
    pots[potID] = {
        object = pot,
        marker = marker,
        state = "empty",
        growth = 0,
        water = 0,
        fertilizer = 0,
        timer = nil,
        plantType = "none"
    }
    
    setElementData(pot, "potID", potID)
    setElementData(marker, "potID", potID)
    outputChatBox("You have placed a pot.", player, 0, 255, 0)
    return true
end

function startDrugSale(player)
    if not isElement(player) then return false end
    
    -- Check if player has required phone
    if not hasInventoryItem(player, Config.REQUIRED_ITEMS.PHONE) then
        outputChatBox("You need a phone to contact dealers!", player, 255, 0, 0)
        return false
    end
    
    -- Check if player already has an active order
    if playerOrders[player] then
        outputChatBox("You already have an active order!", player, 255, 165, 0)
        return false
    end
    
    -- Generate fresh orders for this request
    local orders = generateOrders()
    
    -- Send available orders to client
    triggerClientEvent(player, "receiveDrugOrders", player, orders)
    return true
end

function sellDrugsToDealer(player, amount, orderDetails)
    if not isElement(player) or not amount or not orderDetails then 
        return false
    end
    
    -- Check if player has required phone
    if not hasInventoryItem(player, Config.REQUIRED_ITEMS.PHONE) then
        outputChatBox("You need a phone to contact the dealer!", player, 255, 0, 0)
        return false
    end
    
    -- Validate amount
    amount = tonumber(amount)
    if not amount or amount <= 0 then
        return false
    end
    
    -- Validate order details
    if not orderDetails.amount or not orderDetails.price then
        return false
    end
    
    -- Convert to numbers and validate
    local orderAmount = tonumber(orderDetails.amount)
    local orderPrice = tonumber(orderDetails.price)
    
    if not orderAmount or not orderPrice or orderAmount <= 0 or orderPrice <= 0 then
        return false
    end
    
    -- Check if amount is valid
    if amount > orderAmount then 
        return false
    end
    
    -- Calculate price for this amount
    local pricePerUnit = orderPrice / orderAmount
    local totalPrice = math.floor(pricePerUnit * amount)
    
    if totalPrice <= 0 then
        return false
    end
    
    -- Try to exchange drugs for black money
    if exchangeInventoryItems(player, Config.HARVEST_ITEM, amount, Config.BLACK_MONEY_ITEM, totalPrice) then
        -- Notify player
        outputChatBox("You sold " .. amount .. " units for " .. totalPrice .. " " .. Config.BLACK_MONEY_ITEM .. "!", player, 0, 255, 0)
        
        -- Complete order if all drugs are sold
        if amount >= orderAmount then
            triggerClientEvent(player, "drugOrderCompleted", player)
            playerOrders[player] = nil
        else
            -- Update order amount
            if playerOrders[player] then
                playerOrders[player].amount = orderAmount - amount
                playerOrders[player].price = orderPrice - totalPrice
            end
        end
        return true
    else
        outputChatBox("Failed to complete the deal!", player, 255, 0, 0)
        return false
    end
end

function openDealerPhone(player)
    if not isElement(player) then return false end
    
    -- Check if player has required phone
    if not hasInventoryItem(player, Config.REQUIRED_ITEMS.PHONE) then
        outputChatBox("You need a phone to contact dealers!", player, 255, 0, 0)
        return false
    end
    
    -- Trigger client event to open phone
    triggerClientEvent(player, "openDealerPhoneFromServer", player)
    return true
end

-- Export the functions
exports.placePot = placePot
exports.startDrugSale = startDrugSale
exports.sellDrugsToDealer = sellDrugsToDealer
exports.openDealerPhone = openDealerPhone

-- ====================================
-- Command Handlers
-- ====================================

-- Command to place a pot
addCommandHandler("placepot", function(player)
    placePot(player)
end)

-- Command to start drug sale
addCommandHandler("selldrug", function(player)
    startDrugSale(player)
end)

-- Get item count from inventory
function getInventoryItemCount(player, itemName)
    if not player or not itemName then return 0 end
    local count = inventoryScript:getItem(player, itemName)
    return tonumber(count) or 0
end

-- Check if player has required item amount
function hasInventoryItem(player, itemName, amount)
    if not player or not itemName then return false end
    amount = tonumber(amount) or 1
    local itemCount = getInventoryItemCount(player, itemName)
    return itemCount >= amount
end

-- Take item from player's inventory
function takeInventoryItem(player, itemName, amount)
    if not player or not itemName then return false end
    amount = tonumber(amount) or 1
    if amount <= 0 then return false end
    
    if not inventoryScript:takeItem(player, itemName, amount) then
        outputChatBox("Error: Failed to remove " .. itemName, player, 255, 0, 0)
        return false
    end
    return true
end

-- Give item to player's inventory
function giveInventoryItem(player, itemName, amount)
    if not player or not itemName then return false end
    amount = tonumber(amount) or 1
    if amount <= 0 then return false end
    
    if not inventoryScript:giveItem(player, itemName, amount) then
        outputChatBox("Error: Failed to give " .. itemName, player, 255, 0, 0)
        return false
    end
    return true
end

-- Try to exchange items (take one, give another)
function exchangeInventoryItems(player, takeItemName, takeAmount, giveItemName, giveAmount)
    if not player or not takeItemName or not giveItemName then return false end
    takeAmount = tonumber(takeAmount) or 1
    giveAmount = tonumber(giveAmount) or 1
    
    if takeAmount <= 0 or giveAmount <= 0 then return false end
    
    -- First try to take the item
    if takeInventoryItem(player, takeItemName, takeAmount) then
        -- If giving fails, give back the taken item
        if not giveInventoryItem(player, giveItemName, giveAmount) then
            giveInventoryItem(player, takeItemName, takeAmount)
            return false
        end
        return true
    end
    return false
end

-- Function to check if player has required item
function hasItem(player, itemName, amount)
    return hasInventoryItem(player, itemName, amount)
end

-- Function to remove item from player
function removeItem(player, itemName, amount)
    return takeInventoryItem(player, itemName, amount)
end

-- Function to get pot data for client
function getPotDataForClient(pot)
    if not pot then return nil end
    return {
        state = pot.state or "empty",
        growth = math.floor(tonumber(pot.growth) or 0),
        water = math.floor(tonumber(pot.water) or 0),
        fertilizer = math.floor(tonumber(pot.fertilizer) or 0),
        plantType = pot.plantType or "none"
    }
end

-- Function to check nearby pots
addEvent("checkNearbyPots", true)
addEventHandler("checkNearbyPots", resourceRoot, function()
    if not client then return end
    
    local player = client
    local px, py, pz = getElementPosition(player)
    if not px or not py or not pz then return end
    
    for potID, potData in pairs(pots) do
        if isElement(potData.object) then
            local x, y, z = getElementPosition(potData.object)
            if x and y and z then
                local distance = getDistanceBetweenPoints3D(px, py, pz, x, y, z)
                if distance <= (Config.INTERACTION_DISTANCE or 3) then
                    local potData = getPotDataForClient(potData)
                    if potData then
                        triggerClientEvent(player, "togglePotPanel", resourceRoot, potID, potData)
                        setElementData(player, "viewing_pot_id", potID)
                        return
                    end
                end
            end
        end
    end
    
    -- If no pot is found nearby, clear the viewing pot ID
    setElementData(player, "viewing_pot_id", nil)
end)

-- Function to start growth timer for a pot
function startGrowthTimer(potID)
    local pot = pots[potID]
    if not pot then return end
    
    if isTimer(pot.timer) then
        killTimer(pot.timer)
    end
    
    pot.timer = setTimer(function()
        if not pots[potID] then return end
        
        -- Ensure all values are numbers
        pot.water = tonumber(pot.water) or 0
        pot.fertilizer = tonumber(pot.fertilizer) or 0
        pot.growth = tonumber(pot.growth) or 0
        
        -- Decrease water and fertilizer
        pot.water = math.max(0, pot.water - Config.WATER_DECREASE_RATE)
        pot.fertilizer = math.max(0, pot.fertilizer - Config.FERTILIZER_DECREASE_RATE)
        
        -- Calculate growth based on water and fertilizer levels
        local growthRate = Config.BASE_GROWTH_RATE
        if pot.water > 0 then
            growthRate = growthRate * Config.WATER_GROWTH_MULTIPLIER
        end
        if pot.fertilizer > 0 then
            growthRate = growthRate * Config.FERTILIZER_GROWTH_MULTIPLIER
        end
        
        pot.growth = math.min(100, pot.growth + growthRate)
        
        -- Check if plant is ready
        if pot.growth >= 100 then
            pot.state = "ready"
            if isTimer(pot.timer) then
                killTimer(pot.timer)
            end
        end
        
        -- Update clients
        for _, player in ipairs(getElementsByType("player")) do
            local playerPotID = getElementData(player, "viewing_pot_id")
            if playerPotID == potID then
                triggerClientEvent(player, "updatePotData", resourceRoot, getPotDataForClient(pot))
            end
        end
    end, Config.GROWTH_TIMER_INTERVAL, 0)
end

-- Function to save pot objects (you should call this when resource stops)
function savePotObjects()
    -- Implement saving logic here if needed
end

-- Function to load pot objects (you should call this when resource starts)
function loadPotObjects()
    -- Implement loading logic here if needed
end

-- Initialize orders on resource start
addEventHandler("onResourceStart", resourceRoot, function()
    activeOrders = generateOrders()
    
    -- Refresh orders periodically
    setTimer(function()
        activeOrders = generateOrders()
    end, Config.DRUG_DEALING.ORDER_REFRESH_TIME, 0)
end)

addEventHandler("onResourceStop", resourceRoot, function()
    savePotObjects()
    
    -- Clean up timers
    for _, potData in pairs(pots) do
        if isTimer(potData.timer) then
            killTimer(potData.timer)
        end
        if isElement(potData.object) then
            destroyElement(potData.object)
        end
        if isElement(potData.marker) then
            destroyElement(potData.marker)
        end
    end
    
    -- Clear tables
    pots = {}
    activeOrders = {}
    playerOrders = {}
end)

-- Function to check and set cooldown
function checkCooldown(player, action)
    if not player or not action then return false end
    
    local playerID = getElementData(player, "ID") or "default"
    playerCooldowns[playerID] = playerCooldowns[playerID] or {}
    
    local lastAction = playerCooldowns[playerID][action]
    local currentTime = getTickCount()
    
    if lastAction and currentTime - lastAction < 1000 then
        return false
    end
    
    playerCooldowns[playerID][action] = currentTime
    return true
end

-- Handle pot actions
addEvent("onPotAction", true)
addEventHandler("onPotAction", resourceRoot, function(potID, action)
    if not client or not potID or not action then return end
    
    -- Check cooldown
    if not checkCooldown(client, action) then return end
    
    local pot = pots[potID]
    if not pot then return end
    
    if action == "addSeeds" then
        if pot.state ~= "empty" then
            outputChatBox("This pot already has seeds!", client, 255, 0, 0)
            return
        end
        
        if not hasInventoryItem(client, Config.REQUIRED_ITEMS.SEED) then
            outputChatBox("You need seeds to do this!", client, 255, 0, 0)
            return
        end
        
        if not takeInventoryItem(client, Config.REQUIRED_ITEMS.SEED) then return end
        
        -- Change pot model to plant model
        local x, y, z = getElementPosition(pot.object)
        local rx, ry, rz = getElementRotation(pot.object)
        destroyElement(pot.object)
        pot.object = createObject(Config.OBJECT_MODELS.PLANT_POT, x, y, z)
        setElementRotation(pot.object, rx, ry, rz)
        setElementData(pot.object, "potID", potID)
        
        pot.state = "growing"
        pot.plantType = "cocaine"
        pot.growth = 0
        pot.water = 0
        pot.fertilizer = 0
        startGrowthTimer(potID)
        outputChatBox("You have planted cocaine seeds.", client, 0, 255, 0)
        
    elseif action == "addWater" then
        if pot.state == "empty" then
            outputChatBox("Add seeds first!", client, 255, 0, 0)
            return
        end
        
        if not hasInventoryItem(client, Config.REQUIRED_ITEMS.WATER) then
            outputChatBox("You need water to do this!", client, 255, 0, 0)
            return
        end
        
        if not takeInventoryItem(client, Config.REQUIRED_ITEMS.WATER) then return end
        
        pot.water = math.min(100, pot.water + Config.WATER_EFFECTIVENESS)
        outputChatBox("You have watered the plant.", client, 0, 255, 0)
        
    elseif action == "addFertilizer" then
        if pot.state == "empty" then
            outputChatBox("Add seeds first!", client, 255, 0, 0)
            return
        end
        
        if not hasInventoryItem(client, Config.REQUIRED_ITEMS.FERTILIZER) then
            outputChatBox("You need fertilizer to do this!", client, 255, 0, 0)
            return
        end
        
        if not takeInventoryItem(client, Config.REQUIRED_ITEMS.FERTILIZER) then return end
        
        pot.fertilizer = math.min(100, pot.fertilizer + Config.FERTILIZER_EFFECTIVENESS)
        outputChatBox("You have fertilized the plant.", client, 0, 255, 0)
        
    elseif action == "harvestPlant" then
        if pot.state ~= "ready" then
            outputChatBox("The plant is not ready for harvest!", client, 255, 0, 0)
            return
        end
        
        -- Give harvested items
        if pot.plantType == "cocaine" then
            if not giveInventoryItem(client, Config.HARVEST_ITEM, Config.HARVEST_AMOUNT) then
                outputChatBox("Failed to harvest: Inventory might be full!", client, 255, 0, 0)
                return
            end
            outputChatBox("You have harvested " .. Config.HARVEST_AMOUNT .. " units of " .. Config.HARVEST_ITEM .. "!", client, 0, 255, 0)
        end
        
        -- Reset pot to empty state
        local x, y, z = getElementPosition(pot.object)
        local rx, ry, rz = getElementRotation(pot.object)
        destroyElement(pot.object)
        pot.object = createObject(Config.OBJECT_MODELS.EMPTY_POT, x, y, z)
        setElementRotation(pot.object, rx, ry, rz)
        setElementData(pot.object, "potID", potID)
        
        pot.state = "empty"
        pot.plantType = "none"
        pot.growth = 0
        pot.water = 0
        pot.fertilizer = 0
        
        if isTimer(pot.timer) then
            killTimer(pot.timer)
        end
        
    elseif action == "removePot" then
        if not giveInventoryItem(client, Config.REQUIRED_ITEMS.POT) then
            outputChatBox("Failed to remove pot: Inventory might be full!", client, 255, 0, 0)
            return
        end
        
        -- Destroy pot and clean up
        destroyElement(pot.object)
        if isElement(pot.marker) then
            destroyElement(pot.marker)
        end
        if isTimer(pot.timer) then
            killTimer(pot.timer)
        end
        pots[potID] = nil
        outputChatBox("You have removed the pot.", client, 0, 255, 0)
    end
    
    -- Update panel for any players viewing this pot
    for _, player in ipairs(getElementsByType("player")) do
        local playerPotID = getElementData(player, "viewing_pot_id")
        if playerPotID == potID then
            triggerClientEvent(player, "updatePotData", resourceRoot, getPotDataForClient(pot))
        end
    end
end)

-- Generate random orders
function generateOrders()
    -- Validate Config values and set defaults if needed
    if not Config or not Config.DRUG_DEALING then
        return {}
    end

    -- Set default values if config values are missing
    local minOrders = tonumber(Config.DRUG_DEALING.MIN_ACTIVE_ORDERS) or 1
    local maxOrders = tonumber(Config.DRUG_DEALING.MAX_ACTIVE_ORDERS) or 3
    local minAmount = tonumber(Config.DRUG_DEALING.MIN_ORDER_AMOUNT) or 1
    local maxAmount = tonumber(Config.DRUG_DEALING.MAX_ORDER_AMOUNT) or 10
    local minPrice = tonumber(Config.DRUG_DEALING.MIN_PRICE_PER_GRAM) or 100
    local maxPrice = tonumber(Config.DRUG_DEALING.MAX_PRICE_PER_GRAM) or 200

    -- Ensure max values are greater than min values
    maxOrders = math.max(minOrders, maxOrders)
    maxAmount = math.max(minAmount, maxAmount)
    maxPrice = math.max(minPrice, maxPrice)

    local orders = {}
    local numOrders = math.random(minOrders, maxOrders)
    
    -- Validate dealer locations
    if not Config.DRUG_DEALING.DEALER_LOCATIONS or type(Config.DRUG_DEALING.DEALER_LOCATIONS) ~= "table" or #Config.DRUG_DEALING.DEALER_LOCATIONS == 0 then
        return {}
    end

    -- Create a copy of dealer locations to ensure unique locations
    local availableLocations = table.copy(Config.DRUG_DEALING.DEALER_LOCATIONS)
    
    for i = 1, numOrders do
        -- Break if we run out of locations
        if #availableLocations == 0 then break end

        -- Get random location and remove it from available locations
        local locationIndex = math.random(#availableLocations)
        local location = availableLocations[locationIndex]
        table.remove(availableLocations, locationIndex)
        
        -- Skip invalid locations
        if location and type(location) == "table" then
            -- Generate random amount and price with validation
            local amount = math.random(minAmount, maxAmount)
            local price = amount * math.random(minPrice, maxPrice)
            
            -- Create order with properly formatted data and validation
            local order = {
                location = tostring(location.name or "Unknown Location"),
                coords = {
                    x = tonumber(location.x) or 0,
                    y = tonumber(location.y) or 0,
                    z = tonumber(location.z) or 0
                },
                amount = tonumber(amount),
                price = tonumber(price)
            }
            
            -- Only add order if coordinates are valid
            if not (order.coords.x == 0 and order.coords.y == 0 and order.coords.z == 0) then
                table.insert(orders, order)
            else
                outputDebugString("[Drug System] Error: Invalid coordinates for location")
            end
        else
            outputDebugString("[Drug System] Error: Invalid location data")
        end
    end
    
    if #orders == 0 then
        outputDebugString("[Drug System] Warning: No valid orders generated")
    end
    
    return orders
end

-- Helper function to copy tables
function table.copy(t)
    local copy = {}
    for k, v in pairs(t) do
        if type(v) == "table" then
            copy[k] = table.copy(v)
        else
            copy[k] = v
        end
    end
    return copy
end

-- Handle order requests from clients
addEvent("requestDrugOrders", true)
addEventHandler("requestDrugOrders", root, function()
    if not client then return end
    
    -- Check if player has required phone
    if not hasInventoryItem(client, Config.REQUIRED_ITEMS.PHONE) then
        outputChatBox("You need a phone to contact dealers!", client, 255, 0, 0)
        return
    end
    
    
    -- Check if player already has an active order
    if playerOrders[client] then
        outputChatBox("You already have an active order!", client, 255, 165, 0)
        return
    end
    
    -- Generate fresh orders for this request
    local orders = generateOrders()
    
    -- Send available orders to client
    triggerClientEvent(client, "receiveDrugOrders", client, orders)
end)

-- Handle order selection
addEvent("onDrugOrderSelected", true)
addEventHandler("onDrugOrderSelected", root, function(orderJSON)
    if not client then return end
    
    local order = fromJSON(orderJSON)
    if not order then return end
    
    -- Store the order for the player
    playerOrders[client] = order
    
    -- Remove the order from active orders
    for i, activeOrder in ipairs(activeOrders) do
        if activeOrder.location == order.location then
            table.remove(activeOrders, i)
            break
        end
    end
    
    -- Set a timer to expire the order
    setTimer(function()
        if playerOrders[client] then
            playerOrders[client] = nil
            triggerClientEvent(client, "drugOrderCompleted", client)
            outputChatBox("Your drug order has expired.", client, 255, 165, 0)
        end
    end, Config.DRUG_DEALING.ORDER_EXPIRY_TIME, 1)
end)

-- Clean up player orders when they quit
addEventHandler("onPlayerQuit", root, function()
    playerOrders[source] = nil
end)

-- Check player's drug amount
addEvent("checkDrugAmount", true)
addEventHandler("checkDrugAmount", root, function(orderDetails)
    if not client or not orderDetails then 
        outputDebugString("[Drug System] Invalid checkDrugAmount call")
        return 
    end
    
    -- Check how many drugs the player has
    local drugAmount = inventoryScript:getItem(client, Config.DRUG_ITEM_NAME) or 0
    
    -- Calculate maximum amount they can sell (either what they have or what was ordered)
    local maxAmount = math.min(drugAmount, orderDetails.amount)
    
    if maxAmount > 0 then
        -- Show dealer panel with max amount and price per unit
        local pricePerUnit = orderDetails.price / orderDetails.amount
        triggerClientEvent(client, "showDealerPanel", client, maxAmount, pricePerUnit)
    else
        outputChatBox("You don't have any drugs to sell!", client, 255, 0, 0)
    end
end)

-- Add error handling for inventory exports
local function safeInventoryCall(funcName, ...)
    if not inventoryScript then
        return false
    end
    
    local success, result = pcall(function(...)
        return inventoryScript[funcName](inventoryScript, ...)
    end, ...)
    
    if not success then
        outputDebugString("[Drug System] Error calling inventory." .. funcName .. ": " .. tostring(result), 1)
        return false
    end
    
    return result
end

-- Update inventory functions to use safe calls
function getInventoryItemCount(player, itemName)
    if not player or not itemName then return 0 end
    local count = safeInventoryCall("getItem", player, itemName)
    return tonumber(count) or 0
end

function takeInventoryItem(player, itemName, amount)
    if not player or not itemName then return false end
    amount = tonumber(amount) or 1
    if amount <= 0 then return false end
    return safeInventoryCall("takeItem", player, itemName, amount)
end

function giveInventoryItem(player, itemName, amount)
    if not player or not itemName then return false end
    amount = tonumber(amount) or 1
    if amount <= 0 then return false end
    return safeInventoryCall("giveItem", player, itemName, amount)
end

-- ====================================
-- Event Handlers
-- ====================================

-- Handle drug sale
addEvent("sellDrugsToDealer", true)
addEventHandler("sellDrugsToDealer", resourceRoot, function(amount, orderDetails)
    if not client then return end
    sellDrugsToDealer(client, amount, orderDetails)
end)

-- Add at the top of the file
addEvent("onClientCocaineEffect", true)

function applyCocaineEffect(player)
    if not player or not isElement(player) then
        player = source
    end
    
    if not isElement(player) or getElementType(player) ~= "player" then
        return false
    end
    
    -- Set health and armor server-side
    setElementHealth(player, 100)
    setPedArmor(player, 100)
    
    -- Trigger the visual effect on the client
    triggerClientEvent(player, "onClientCocaineEffect", player)
    
    return true
end 