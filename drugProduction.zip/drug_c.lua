local panelBrowser = nil
local currentPotID = nil
local screenW, screenH = guiGetScreenSize()


-- Client-side cocaine effect -------------------------------------------------------
-- Client-side cocaine effect
local isCokeEffectActive = false
local cokeEffectDuration = 20000 -- 20 seconds
local cokeEffectStartTime = 0
local effectTimer = nil
local screenW, screenH = guiGetScreenSize()
local oldWalkingStyle = nil

function applyCocaineEffect()
    if isCokeEffectActive then return false end
    
    isCokeEffectActive = true
    cokeEffectStartTime = getTickCount()

    -- Save old walking style & apply drunk style
    oldWalkingStyle = getPedWalkingStyle(localPlayer)
    setPedWalkingStyle(localPlayer, 126) -- drunk walk + run anim

    -- Restore player health & armor
    setElementHealth(localPlayer, 100)
    setPedArmor(localPlayer, 100)

    -- Start render effect
    addEventHandler("onClientRender", root, renderCocaineEffect)
    effectTimer = setTimer(stopCocaineEffect, cokeEffectDuration, 1)

    return true
end
addCommandHandler("coke", applyCocaineEffect) -- test with /coke

function renderCocaineEffect()
    if not isCokeEffectActive then return end

    local now = getTickCount()
    local elapsed = now - cokeEffectStartTime
    local progress = elapsed / cokeEffectDuration
    if progress >= 1 then stopCocaineEffect() return end

    -- Intensity high in middle, fades at start/end
    local intensity = math.sin(progress * math.pi)

    -- Player position & rotation
    local px, py, pz = getElementPosition(localPlayer)
    local _, _, prot = getElementRotation(localPlayer)

    -- Calculate camera offset behind player
    local distance = 4      -- how far behind
    local height = 1.5      -- how high above ground
    local radRot = math.rad(prot)
    local cx = px - math.sin(radRot) * distance
    local cy = py + math.cos(radRot) * distance
    local cz = pz + height

    -- Look at player normally
    local lx, ly, lz = px, py, pz + 1

    -- Apply small eyeball roll (15° max)
    local rollRadius = 0.25 * intensity -- small wobble radius
    local rollAngle = (now / 800) % (2 * math.pi)
    lx = lx + math.cos(rollAngle) * rollRadius
    ly = ly + math.sin(rollAngle) * rollRadius

    -- Set camera
    setCameraMatrix(cx, cy, cz, lx, ly, lz)

    -- Random white flicker
    if math.random(1, 40) == 1 then
        dxDrawRectangle(0, 0, screenW, screenH, tocolor(255, 255, 255, 50))
    end
end

function stopCocaineEffect()
    if not isCokeEffectActive then return end
    isCokeEffectActive = false

    -- Reset walk style
    if oldWalkingStyle then
        setPedWalkingStyle(localPlayer, oldWalkingStyle)
        oldWalkingStyle = nil
    else
        setPedWalkingStyle(localPlayer, 0)
    end

    -- Reset camera
    setCameraTarget(localPlayer)

    -- Remove render
    removeEventHandler("onClientRender", root, renderCocaineEffect)

    if isTimer(effectTimer) then killTimer(effectTimer) end
end

-- Reset if resource stops
addEventHandler("onClientResourceStop", resourceRoot, function()
    if oldWalkingStyle then
        setPedWalkingStyle(localPlayer, oldWalkingStyle)
    else
        setPedWalkingStyle(localPlayer, 0)
    end
    setCameraTarget(localPlayer)
end)


----------------------------------------------------------------------------------------
-- Add event handler for server trigger
addEvent("onClientCocaineEffect", true)
addEventHandler("onClientCocaineEffect", root, applyCocaineEffect)

-- Drug selling variables
local drugDealerPed = nil
local phonePanel = nil
local phoneBrowser = nil
local hasActiveOrder = false
local browserReady = false
local activeOrderStartTime = 0
local activeOrderTimeout = 0
local possibleLocations = {
    {x = 1234.5, y = -2345.6, z = 12.3, name = "Downtown Alley"},
    {x = 2345.6, y = -1234.5, z = 10.5, name = "Beach Side"},
    {x = -1234.5, y = 2345.6, z = 15.7, name = "Industrial Zone"},
    {x = -2345.6, y = 1234.5, z = 11.2, name = "Suburban Area"},
    {x = 345.6, y = -456.7, z = 13.4, name = "Market District"}
}

-- Add dealer interaction variables
local dealerBrowser = nil
local dealerBrowserReady = false
local nearDealer = false

-- Dealer panel variables
local isDealerPanelVisible = false
local currentAmount = 1
local maxAmount = 1
local pricePerUnit = 0

-- Colors
local colors = {
    background = tocolor(40, 40, 40, 240),
    header = tocolor(60, 60, 60, 255),
    button = tocolor(76, 175, 80, 255),
    buttonHover = tocolor(69, 160, 73, 255),
    sellButton = tocolor(244, 67, 54, 255),
    sellButtonHover = tocolor(211, 47, 47, 255),
    text = tocolor(255, 255, 255, 255),
    shadow = tocolor(0, 0, 0, 100)
}

-- Button states
local buttonStates = {
    decrease = false,
    increase = false,
    sell = false,
    close = false
}

-- Panel dimensions
local panel = {
    width = 300,
    height = 200,
    x = screenW/2 - 150,
    y = screenH/2 - 100
}

-- Progress bar variables
local progressBrowser = nil
local progressBrowserReady = false
local isActionInProgress = false
local pendingActionText = nil
local pendingActionDuration = nil

-- Animation configurations
local actionAnimations = {
    addSeeds = {"BOMBER", "BOM_Plant", -1, false, false, false},
    addWater = {"BOMBER", "BOM_Plant", -1, false, false, false},
    addFertilizer = {"BOMBER", "BOM_Plant", -1, false, false, false},
    harvestPlant = {"BOMBER", "BOM_Plant", -1, false, false, false},
    removePot = {"BOMBER", "BOM_Plant", -1, false, false, false}
}

-- Action durations (in milliseconds)
local actionDurations = {
    addSeeds = Config.PROGRESS_DURATIONS.ADD_SEEDS,
    addWater = Config.PROGRESS_DURATIONS.ADD_WATER,
    addFertilizer = Config.PROGRESS_DURATIONS.ADD_FERTILIZER,
    harvestPlant = Config.PROGRESS_DURATIONS.HARVEST,
    removePot = Config.PROGRESS_DURATIONS.REMOVE_POT
}

-- Add near pot tracking
local nearPot = false

-- Create and show the pot interaction panel
function showPotPanel(potID, potData)
    if isElement(panelBrowser) then
        local browser = guiGetBrowser(panelBrowser)
        if browser then
            updatePanelData(browser, potData)
            return
        end
        hidePotPanel()
    end
    
    local x = (screenW - Config.PANEL_WIDTH) / 2
    local y = (screenH - Config.PANEL_HEIGHT) / 2
    
    panelBrowser = guiCreateBrowser(x, y, Config.PANEL_WIDTH, Config.PANEL_HEIGHT, true, true, false)
    
    if not panelBrowser then return end
    
    currentPotID = potID
    setElementData(localPlayer, "viewing_pot_id", potID)
    
    local browser = guiGetBrowser(panelBrowser)
    
    addEventHandler("onClientBrowserCreated", browser, function()
        loadBrowserURL(browser, "http://mta/local/html/panel.html")
    end)

    addEventHandler("onClientBrowserDocumentReady", browser, function()
        setTimer(function()
            updatePanelData(browser, potData)
        end, 100, 1)
    end)
    
    showCursor(true)
    guiSetInputMode("no_binds_when_editing")
end

-- Function to update panel data
function updatePanelData(browser, potData)
    if not browser or not potData then return end

    local updateScript = string.format([[
        if(typeof updatePotData === 'function') {
            updatePotData({
                state: '%s',
                growth: %d,
                water: %d,
                fertilizer: %d,
                plantType: '%s'
            });
        }
    ]], 
    potData.state or "empty",
    potData.growth or 0,
    potData.water or 0,
    potData.fertilizer or 0,
    potData.plantType or "none")

    executeBrowserJavascript(browser, updateScript)
end

-- Hide the pot interaction panel
function hidePotPanel()
    if isElement(panelBrowser) then
        destroyElement(panelBrowser)
        panelBrowser = nil
        currentPotID = nil
        setElementData(localPlayer, "viewing_pot_id", nil)
        showCursor(false)
        guiSetInputMode("allow_binds")
    end
end

-- Handle pot panel toggle event from server
addEvent("togglePotPanel", true)
addEventHandler("togglePotPanel", root, function(potID, potData)
    if not potID or not potData then
        hidePotPanel()
        return
    end
    
    showPotPanel(potID, potData)
end)

-- Handle pot data updates from server
addEvent("updatePotData", true)
addEventHandler("updatePotData", root, function(potData)
    if isElement(panelBrowser) then
        local browser = guiGetBrowser(panelBrowser)
        if browser then
            updatePanelData(browser, potData)
        end
    end
end)

-- Handle actions from the HTML panel
addEvent("onPanelAction", true)
addEventHandler("onPanelAction", root, function(action)
    if not action then return end
    
    -- Hide the panel and clear interaction state
    if isElement(panelBrowser) then
        destroyElement(panelBrowser)
        panelBrowser = nil
        showCursor(false)
    end
    nearPot = false
    
    -- Start the action with progress bar and animation
    if startAction(action) then
        -- After the action is complete, trigger the server event
        local duration = actionDurations[action]
        setTimer(function()
            if currentPotID then
                triggerServerEvent("onPotAction", resourceRoot, currentPotID, action)
            end
        end, duration, 1)
    end
end)

-- Add key bind to trigger pot check or close panel
bindKey("e", "down", function()
    -- If panel is open, close it
    if isElement(panelBrowser) then
        hidePotPanel()
    else
        -- If no panel is open, check for nearby pots
        triggerServerEvent("checkNearbyPots", resourceRoot)
    end
end)

-- Add browser event handler for panel actions
addEventHandler("onClientBrowserJavascriptEvent", root, function(eventName, args)
    if eventName == "onPanelAction" and type(args) == "table" and #args > 0 then
        local action = args[1]
        if currentPotID then
            triggerServerEvent("onPotAction", resourceRoot, currentPotID, action)
        end
    end
end)

-- Create browser for phone panel
addEventHandler("onClientResourceStart", resourceRoot, function()
    local x = screenW - (Config.DRUG_DEALING.PHONE_WIDTH + 20)
    local y = screenH - (Config.DRUG_DEALING.PHONE_HEIGHT + 20)
    
    phonePanel = guiCreateBrowser(x, y, Config.DRUG_DEALING.PHONE_WIDTH, Config.DRUG_DEALING.PHONE_HEIGHT, true, true, false)
    
    if phonePanel then
        phoneBrowser = guiGetBrowser(phonePanel)
        
        addEventHandler("onClientBrowserCreated", phoneBrowser, function()
            loadBrowserURL(phoneBrowser, "http://mta/local/html/phone_panel.html")
        end)
        
        addEventHandler("onClientBrowserDocumentReady", phoneBrowser, function()
            browserReady = true
            guiSetVisible(phonePanel, false)
        end)
    end
end)

-- Function to update phone content
function updatePhoneContent()
    if hasActiveOrder then
        local currentTime = getTickCount()
        local elapsedTime = currentTime - activeOrderStartTime
        local remainingTime = math.max(0, activeOrderTimeout - elapsedTime)
        local remainingMinutes = math.floor(remainingTime / 1000 / 60)
        local remainingSeconds = math.floor((remainingTime / 1000) % 60)
        
        executeBrowserJavascript(phoneBrowser, string.format("updateActiveOrder(%d, %d);", remainingMinutes, remainingSeconds))
    else
        triggerServerEvent("requestDrugOrders", localPlayer)
    end
end

-- Function to toggle phone panel
function openDealerPhone()
    if not phonePanel or not phoneBrowser or not browserReady then return false end
    
    if not guiGetVisible(phonePanel) then
        guiSetVisible(phonePanel, true)
        showCursor(true)
        executeBrowserJavascript(phoneBrowser, "showPanel();")
        setTimer(updatePhoneContent, 100, 1)
        return true
    else
        guiSetVisible(phonePanel, false)
        showCursor(false)
        executeBrowserJavascript(phoneBrowser, "hidePanel();")
        return true
    end
end

-- Handle server-side phone open request
addEvent("openDealerPhoneFromServer", true)
addEventHandler("openDealerPhoneFromServer", root, function()
    openDealerPhone()
end)

-- Command to toggle phone panel
addCommandHandler("selldrug", function()
    openDealerPhone()
end)

-- Receive orders from server
addEvent("receiveDrugOrders", true)
addEventHandler("receiveDrugOrders", root, function(orders)
    if not phonePanel or not phoneBrowser or not browserReady then return end
    
    -- Manually construct the JavaScript array string
    local ordersString = "["
    for i, order in ipairs(orders) do
        if i > 1 then ordersString = ordersString .. "," end
        ordersString = ordersString .. string.format(
            '{location:"%s",coords:{x:%f,y:%f,z:%f},amount:%d,price:%d}',
            order.location,
            order.coords.x,
            order.coords.y,
            order.coords.z,
            order.amount,
            order.price
        )
    end
    ordersString = ordersString .. "]"
    
    executeBrowserJavascript(phoneBrowser, "updateOrders(" .. ordersString .. ");")
end)

-- Handle order selection
addEvent("onDrugOrderSelected", true)
addEventHandler("onDrugOrderSelected", root, function(orderJSON)
    local order = fromJSON(orderJSON)
    if not order then return end
    
    -- Remove existing dealer if any
    if drugDealerPed and isElement(drugDealerPed) then
        destroyElement(drugDealerPed)
    end
    
    -- Set active order flag and start time
    hasActiveOrder = true
    activeOrderStartTime = getTickCount()
    activeOrderTimeout = Config.DRUG_DEALING.DEALER_TIMEOUT
    
    -- Create the drug dealer NPC
    local skinID = Config.DRUG_DEALING.DEALER_SKIN_IDS[math.random(#Config.DRUG_DEALING.DEALER_SKIN_IDS)]
    drugDealerPed = createPed(skinID, order.coords.x, order.coords.y, order.coords.z)
    setElementData(drugDealerPed, "drugDealer", true)
    setElementData(drugDealerPed, "orderDetails", order)
    
    -- Add blip for the dealer
    local blip = createBlip(order.coords.x, order.coords.y, order.coords.z, 51)
    setElementData(drugDealerPed, "dealerBlip", blip)
    
    -- Start dealer timeout timer
    setTimer(function()
        if drugDealerPed and isElement(drugDealerPed) then
            local blip = getElementData(drugDealerPed, "dealerBlip")
            if blip and isElement(blip) then
                destroyElement(blip)
            end
            destroyElement(drugDealerPed)
            hasActiveOrder = false
            outputChatBox("The dealer got tired of waiting and left.", 255, 165, 0)
        end
    end, Config.DRUG_DEALING.DEALER_TIMEOUT, 1)
    
    -- Update phone content
    setTimer(updatePhoneContent, 100, 1)
    
    -- Notify the player
    outputChatBox("Drug dealer location has been marked on your map.", 0, 255, 0)
    outputChatBox("You have " .. math.floor(Config.DRUG_DEALING.DEALER_TIMEOUT/1000/60) .. " minutes to meet the dealer.", 255, 255, 0)
end)

-- Handle order completion
addEvent("drugOrderCompleted", true)
addEventHandler("drugOrderCompleted", root, function()
    hasActiveOrder = false
    if drugDealerPed and isElement(drugDealerPed) then
        local blip = getElementData(drugDealerPed, "dealerBlip")
        if blip and isElement(blip) then
            destroyElement(blip)
        end
        destroyElement(drugDealerPed)
    end
    
    if guiGetVisible(phonePanel) then
        updatePhoneContent()
    end
end)

-- Add event handler for closing panel from HTML
addEvent("hidePhonePanel", true)
addEventHandler("hidePhonePanel", root, function()
    if phonePanel then
        guiSetVisible(phonePanel, false)
        showCursor(false)
    end
end)

-- Add browser debug event handler
addEvent("browserDebug", true)
addEventHandler("browserDebug", root, function(message)
    outputDebugString("[Browser] " .. tostring(message))
end)

-- Create dealer interaction panel
addEventHandler("onClientResourceStart", resourceRoot, function()
    outputDebugString("[Drug System] Starting dealer panel initialization")
    
    -- Request browser permissions if needed
    if not isBrowserDomainBlocked("mta", true) then
        requestBrowserDomains({"mta"}, true, function(accepted, newDomains)
            if accepted then
                initializeDealerPanel()
            else
                outputDebugString("[Drug System] Browser domain not accepted!", 1)
            end
        end)
    else
        initializeDealerPanel()
    end
end)

function initializeDealerPanel()
    outputDebugString("[Drug System] Initializing dealer panel")
    
    -- Calculate center position
    local x = screenW/2 - 150
    local y = screenH/2 - 100
    
    -- Create browser directly without GUI window
    dealerBrowser = createBrowser(300, 200, true, true)
    
    if not dealerBrowser then
        outputDebugString("[Drug System] Failed to create browser!", 1)
        return
    end
    
    -- Set browser position
    setBrowserPosition(dealerBrowser, x, y)
    setBrowserVisible(dealerBrowser, false)
    
    -- Add event handlers
    addEventHandler("onClientBrowserCreated", dealerBrowser, function()
        outputDebugString("[Drug System] Browser created, loading URL")
        loadBrowserURL(dealerBrowser, "http://mta/local/html/dealer_panel.html")
    end)
    
    addEventHandler("onClientBrowserDocumentReady", dealerBrowser, function()
        outputDebugString("[Drug System] Browser document ready")
        dealerBrowserReady = true
    end)
    
    -- Add browser debug event
    addEventHandler("onClientBrowserJavascriptEvent", dealerBrowser, function(eventName, args)
        outputDebugString("[Drug System] Browser event: " .. tostring(eventName))
    end)
end

-- Draw dealer panel
addEventHandler("onClientRender", root, function()
    if not isDealerPanelVisible then return end
    
    -- Draw panel background
    dxDrawRectangle(panel.x, panel.y, panel.width, panel.height, colors.background)
    
    -- Draw header
    dxDrawRectangle(panel.x, panel.y, panel.width, 40, colors.header)
    dxDrawText("Drug Deal", panel.x, panel.y, panel.x + panel.width - 40, panel.y + 40, colors.text, 1.2, "default-bold", "center", "center")
    
    -- Draw close button
    local closeSize = 30
    local closeX = panel.x + panel.width - 35
    local closeY = panel.y + 5
    local closeColor = buttonStates.close and colors.sellButtonHover or colors.sellButton
    dxDrawRectangle(closeX, closeY, closeSize, closeSize, closeColor)
    dxDrawText("X", closeX, closeY, closeX + closeSize, closeY + closeSize, colors.text, 1.2, "default-bold", "center", "center")
    
    -- Draw amount controls
    local amountY = panel.y + 60
    local btnWidth = 40
    local btnHeight = 40
    local btnSpacing = 20
    local centerX = panel.x + (panel.width / 2)
    
    -- Decrease button
    local decreaseX = centerX - btnWidth - btnSpacing
    local decreaseColor = buttonStates.decrease and colors.buttonHover or colors.button
    dxDrawRectangle(decreaseX, amountY, btnWidth, btnHeight, decreaseColor)
    dxDrawText("-", decreaseX, amountY, decreaseX + btnWidth, amountY + btnHeight, colors.text, 2, "default-bold", "center", "center")
    
    -- Amount display
    dxDrawRectangle(centerX - 30, amountY, 60, btnHeight, colors.header)
    dxDrawText(tostring(currentAmount), centerX - 30, amountY, centerX + 30, amountY + btnHeight, colors.text, 1.2, "default-bold", "center", "center")
    
    -- Increase button
    local increaseX = centerX + btnSpacing
    local increaseColor = buttonStates.increase and colors.buttonHover or colors.button
    dxDrawRectangle(increaseX, amountY, btnWidth, btnHeight, increaseColor)
    dxDrawText("+", increaseX, amountY, increaseX + btnWidth, amountY + btnHeight, colors.text, 2, "default-bold", "center", "center")
    
    -- Draw price
    local priceY = amountY + btnHeight + 20
    local totalPrice = currentAmount * pricePerUnit
    dxDrawText("Price: $" .. tostring(totalPrice), panel.x + 20, priceY, panel.x + panel.width - 20, priceY + 30, colors.text, 1.2, "default-bold", "center", "center")
    
    -- Draw sell button
    local sellY = panel.y + panel.height - 50
    local sellColor = buttonStates.sell and colors.sellButtonHover or colors.sellButton
    dxDrawRectangle(panel.x + 20, sellY, panel.width - 40, 40, sellColor)
    dxDrawText("SELL", panel.x + 20, sellY, panel.x + panel.width - 20, sellY + 40, colors.text, 1.2, "default-bold", "center", "center")
end)

-- Handle clicks
addEventHandler("onClientClick", root, function(button, state, absoluteX, absoluteY)
    if not isDealerPanelVisible or button ~= "left" then return end
    
    -- Close button
    local closeSize = 30
    local closeX = panel.x + panel.width - 35
    local closeY = panel.y + 5
    if absoluteX >= closeX and absoluteX <= closeX + closeSize and
       absoluteY >= closeY and absoluteY <= closeY + closeSize then
        hideDealerPanel()
        playSoundFrontEnd(4) -- Click sound
        return
    end
    
    local btnWidth = 40
    local btnHeight = 40
    local btnSpacing = 20
    local centerX = panel.x + (panel.width / 2)
    local amountY = panel.y + 60
    
    -- Decrease button
    local decreaseX = centerX - btnWidth - btnSpacing
    if absoluteX >= decreaseX and absoluteX <= decreaseX + btnWidth and
       absoluteY >= amountY and absoluteY <= amountY + btnHeight then
        if currentAmount > 1 then
            currentAmount = currentAmount - 1
            playSoundFrontEnd(4) -- Click sound
        end
    end
    
    -- Increase button
    local increaseX = centerX + btnSpacing
    if absoluteX >= increaseX and absoluteX <= increaseX + btnWidth and
       absoluteY >= amountY and absoluteY <= amountY + btnHeight then
        if currentAmount < maxAmount then
            currentAmount = currentAmount + 1
            playSoundFrontEnd(4) -- Click sound
        end
    end
    
    -- Sell button
    local sellY = panel.y + panel.height - 50
    if absoluteX >= panel.x + 20 and absoluteX <= panel.x + panel.width - 20 and
       absoluteY >= sellY and absoluteY <= sellY + 40 then
        if drugDealerPed and isElement(drugDealerPed) then
            local orderDetails = getElementData(drugDealerPed, "orderDetails")
            if orderDetails then
                triggerServerEvent("sellDrugsToDealer", resourceRoot, currentAmount, orderDetails)
                hideDealerPanel()
                playSoundFrontEnd(5) -- Confirm sound
            end
        end
    end
end)

-- Handle cursor movement for button hover states
addEventHandler("onClientCursorMove", root, function(_, _, absoluteX, absoluteY)
    if not isDealerPanelVisible then return end
    
    -- Close button hover
    local closeSize = 30
    local closeX = panel.x + panel.width - 35
    local closeY = panel.y + 5
    buttonStates.close = (absoluteX >= closeX and absoluteX <= closeX + closeSize and
                         absoluteY >= closeY and absoluteY <= closeY + closeSize)
    
    local btnWidth = 40
    local btnHeight = 40
    local btnSpacing = 20
    local centerX = panel.x + (panel.width / 2)
    local amountY = panel.y + 60
    
    -- Decrease button hover
    local decreaseX = centerX - btnWidth - btnSpacing
    buttonStates.decrease = (absoluteX >= decreaseX and absoluteX <= decreaseX + btnWidth and
                           absoluteY >= amountY and absoluteY <= amountY + btnHeight)
    
    -- Increase button hover
    local increaseX = centerX + btnSpacing
    buttonStates.increase = (absoluteX >= increaseX and absoluteX <= increaseX + btnWidth and
                           absoluteY >= amountY and absoluteY <= amountY + btnHeight)
    
    -- Sell button hover
    local sellY = panel.y + panel.height - 50
    buttonStates.sell = (absoluteX >= panel.x + 20 and absoluteX <= panel.x + panel.width - 20 and
                        absoluteY >= sellY and absoluteY <= sellY + 40)
end)

-- Show dealer panel
addEvent("showDealerPanel", true)
addEventHandler("showDealerPanel", root, function(max, price)
    outputDebugString("[Drug System] Showing dealer panel: Amount=" .. tostring(max) .. ", Price=" .. tostring(price))
    maxAmount = max
    currentAmount = 1
    pricePerUnit = price
    isDealerPanelVisible = true
    showCursor(true)
end)

-- Hide dealer panel
function hideDealerPanel()
    isDealerPanelVisible = false
    showCursor(false)
    buttonStates.decrease = false
    buttonStates.increase = false
    buttonStates.sell = false
    buttonStates.close = false
end

-- Add key handler for closing dealer panel with Escape
bindKey("escape", "down", function()
    if isDealerPanelVisible then
        hideDealerPanel()
    end
end)

-- Check distance to dealer
addEventHandler("onClientRender", root, function()
    if not hasActiveOrder or not drugDealerPed or not isElement(drugDealerPed) then 
        if nearDealer then
            nearDealer = false
        end
        return 
    end

    local px, py, pz = getElementPosition(localPlayer)
    local dx, dy, dz = getElementPosition(drugDealerPed)
    local distance = getDistanceBetweenPoints3D(px, py, pz, dx, dy, dz)
    
    local wasNear = nearDealer
    nearDealer = distance <= Config.INTERACTION_DISTANCE
    
    -- Show/hide interaction message
    if nearDealer and not wasNear then
        outputChatBox("Press E to interact with the dealer", 255, 255, 0)
    end
end)

-- Handle dealer interaction key
bindKey("e", "down", function()
    if not nearDealer or not drugDealerPed or not isElement(drugDealerPed) then return end
    
    outputDebugString("Checking drug amount...")
    
    -- Get order details
    local orderDetails = getElementData(drugDealerPed, "orderDetails")
    if not orderDetails then 
        outputChatBox("No order details found!", 255, 0, 0)
        return 
    end
    
    -- Check player's drug amount
    triggerServerEvent("checkDrugAmount", localPlayer, orderDetails)
end)

-- Clean up on resource stop
addEventHandler("onClientResourceStop", resourceRoot, function()
    if dealerBrowser and isElement(dealerBrowser) then
        destroyElement(dealerBrowser)
    end
end)

-- Initialize progress bar on resource start
addEventHandler("onClientResourceStart", resourceRoot, function()
    -- Request browser permissions if needed
    if not isBrowserDomainBlocked("mta", true) then
        requestBrowserDomains({"mta"}, true, function(accepted, newDomains)
            if accepted then
                outputDebugString("[Drug System] Browser domain accepted")
            else
                outputDebugString("[Drug System] Browser domain not accepted!", 1)
            end
        end)
    end
end)

-- Function to show progress bar
function showProgressBar(action, duration)
    if isElement(progressBrowser) then
        destroyElement(progressBrowser)
        progressBrowser = nil
    end
    
    local x = (screenW - Config.PANEL_WIDTH) / 2
    local y = screenH - 150  -- Position near bottom
    
    progressBrowser = guiCreateBrowser(x, y, Config.PANEL_WIDTH, 100, true, true, false)
    
    if not progressBrowser then return end
    
    local browser = guiGetBrowser(progressBrowser)
    
    addEventHandler("onClientBrowserCreated", browser, function()
        loadBrowserURL(browser, "http://mta/local/html/progress_bar.html")
    end)
    
    addEventHandler("onClientBrowserDocumentReady", browser, function()
        progressBrowserReady = true
        executeBrowserJavascript(browser, string.format([[
            if(typeof showProgress === 'function') {
                showProgress('%s...', %d);
            }
        ]], action:gsub("([A-Z])", " %1"):gsub("^%s", ""), duration))
    end)
end

-- Function to hide progress bar
function hideProgressBar()
    if isElement(progressBrowser) then
        destroyElement(progressBrowser)
        progressBrowser = nil
        progressBrowserReady = false
    end
end

-- Function to handle action start
function startAction(action)
    if isActionInProgress then return false end
    
    -- Get action configuration
    local duration = actionDurations[action]
    local animation = actionAnimations[action]
    
    if not duration or not animation then return false end
    
    -- Start animation
    setPedAnimation(localPlayer, unpack(animation))
    
    -- Show progress bar
    showProgressBar(action, duration)
    
    -- Disable controls
    toggleAllControls(false)
    isActionInProgress = true
    
    -- Set timer to end action
    setTimer(function()
        endAction()
    end, duration, 1)
    
    return true
end

-- Function to end action
function endAction()
    if not isActionInProgress then return end
    
    -- Stop animation
    setPedAnimation(localPlayer)
    
    -- Enable controls
    toggleAllControls(true)
    isActionInProgress = false
    
    -- Hide progress bar
    hideProgressBar()
end

-- Clean up on resource stop
addEventHandler("onClientResourceStop", resourceRoot, function()
    if isElement(progressBrowser) then
        destroyElement(progressBrowser)
        progressBrowser = nil
        progressBrowserReady = false
    end
end)

-- Test command for progress bar
addCommandHandler("testprogress", function()
    startAction("addWater")
end)

-- Request browser permissions on resource start
addEventHandler("onClientResourceStart", resourceRoot, function()
    requestBrowserDomains({"mta"}, true, function(accepted, newDomains)
        if accepted then
            --outputChatBox("Browser domains accepted")
        else
            --outputChatBox("Browser domains not accepted!", 255, 0, 0)
        end
    end)
end)

-- Function to draw interaction text
function drawInteractionText()
    if nearPot and not isElement(panelBrowser) then
        local text = "Press [E] - to interact"
        local textWidth = dxGetTextWidth(text, 1.2, "default-bold")
        local x = (screenW - textWidth) / 2
        local y = screenH - 100
        dxDrawText(text, x, y, x + textWidth, y + 20, tocolor(255, 255, 255, 255), 1.2, "default-bold", "left", "top", false, false, true)
    end
end
addEventHandler("onClientRender", root, drawInteractionText)

-- Handle marker hit/leave
addEventHandler("onClientMarkerHit", root, function(hitElement, matchingDimension)
    if hitElement == localPlayer and matchingDimension then
        local potID = getElementData(source, "potID")
        if potID and not isElement(panelBrowser) then
            nearPot = true
        end
    end
end)

addEventHandler("onClientMarkerLeave", root, function(leaveElement, matchingDimension)
    if leaveElement == localPlayer and matchingDimension then
        local potID = getElementData(source, "potID")
        if potID then
            nearPot = false
        end
    end
end)