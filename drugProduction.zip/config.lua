inventoryScript = exports.inventory

Config = {
    -- Panel dimensions
    PANEL_WIDTH = 800,
    PANEL_HEIGHT = 600,
    
    -- Object Models
    OBJECT_MODELS = {
        EMPTY_POT = 2203,  -- Empty flower pot
        PLANT_POT = 2241   -- Pot with plant
    },

    -- Progress Bar Durations (in milliseconds)
    PROGRESS_DURATIONS = {
        ADD_SEEDS = 5000,      -- 5 seconds
        ADD_WATER = 3000,      -- 3 seconds
        ADD_FERTILIZER = 4000, -- 4 seconds
        HARVEST = 6000,        -- 6 seconds
        REMOVE_POT = 3000      -- 3 seconds
    },
    
    -- Interaction settings
    INTERACTION_DISTANCE = 3,
    MARKER_SIZE = 0.8,         -- Size of the interaction marker
    MARKER_COLOR = {           -- RGBA color for marker
        r = 255,
        g = 255,
        b = 0,
        a = 0
    },
    
    -- Required items
    REQUIRED_ITEMS = {
        POT = "Pot",
        SEED = "Seed",
        WATER = "water",
        FERTILIZER = "Fertilizer",
        PHONE = "Nokia"
    },
    
    -- Growth settings
    GROWTH_TIMER_INTERVAL = 300, -- default 30000
    BASE_GROWTH_RATE = 1,
    WATER_GROWTH_MULTIPLIER = 1.5,
    FERTILIZER_GROWTH_MULTIPLIER = 1.5,
    
    -- Resource consumption rates
    WATER_DECREASE_RATE = 1,
    FERTILIZER_DECREASE_RATE = 1,
    
    -- Effectiveness rates
    WATER_EFFECTIVENESS = 25, -- How much water is added per water bottle
    FERTILIZER_EFFECTIVENESS = 25, -- How much fertilizer is added per fertilizer item
    
    -- Harvest settings
    HARVEST_ITEM = "Cocaine",
    HARVEST_AMOUNT = 1, -- Units per harvest

    -- Drug Dealing Settings
    DRUG_DEALING = {
        -- Phone UI Settings
        PHONE_WIDTH = 350,
        PHONE_HEIGHT = 600,
        MAX_VISIBLE_ORDERS = 5,
        ORDER_REFRESH_TIME = 300000, -- 5 minutes in milliseconds
        
        -- Pricing Settings
        MIN_PRICE_PER_UNIT = 100,  -- Changed from MIN_PRICE_PER_GRAM
        MAX_PRICE_PER_UNIT = 200,  -- Changed from MAX_PRICE_PER_GRAM
        MIN_ORDER_AMOUNT = 1,
        MAX_ORDER_AMOUNT = 10,
        
        -- Dealer Locations (x, y, z coordinates and location names)
        DEALER_LOCATIONS = {
            {x = 2495.7, y = -1687.0, z = 13.5, name = "Grove Street Corner"},
            {x = 2448.3, y = -1970.9, z = 13.5, name = "Behind Cluckin' Bell"},
            {x = 2222.9, y = -1725.4, z = 13.5, name = "Ganton Basketball Court"},
            {x = 2632.7, y = -1785.2, z = 13.5, name = "Abandoned Building Alley"},
            {x = 2349.1, y = -1859.5, z = 13.5, name = "Train Tracks"},
            {x = 2480.8, y = -1536.6, z = 24.0, name = "Rooftop Spot"},
            {x = 2397.8, y = -1899.0, z = 13.5, name = "Dark Alley"},
            {x = 2090.9, y = -1806.7, z = 13.5, name = "Warehouse District"},
            {x = 2418.5, y = -1219.2, z = 25.0, name = "Jefferson Heights"},
            {x = 2307.4, y = -1650.2, z = 14.8, name = "Behind Gas Station"},
            {x = 2185.6, y = -1815.8, z = 13.5, name = "Abandoned Parking Lot"},
            {x = 2552.9, y = -1633.5, z = 13.5, name = "East Side Alley"},
            {x = 2293.2, y = -1882.4, z = 13.5, name = "South Side Corner"},
            {x = 2422.7, y = -1782.1, z = 13.5, name = "Behind Church"},
            {x = 2157.4, y = -1696.3, z = 13.5, name = "West Side Backstreet"}
        },
        
        -- Dealer Settings
        DEALER_SKIN_IDS = {28, 29, 30, 32}, -- Different dealer skin IDs for variety
        DEALER_TIMEOUT = 300000, -- 5 minutes in milliseconds (dealer disappears if player doesn't interact)
        
        -- Order Settings
        MIN_ACTIVE_ORDERS = 1,
        MAX_ACTIVE_ORDERS = 3,
        ORDER_EXPIRY_TIME = 300000 -- 5 minutes in milliseconds
    },

    DRUG_ITEM_NAME = "Cocaine",  -- Name of the drug item in inventory
    BLACK_MONEY_ITEM = "GoldBar",  -- Name of black money item in inventory
    DEALER_INTERACTION_KEY = "e"  -- Key to interact with dealer
} 